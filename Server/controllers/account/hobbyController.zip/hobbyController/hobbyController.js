const { response } = require("express");
const oracledb = require("oracledb");

const config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  connectString: process.env.DB_CONNECTION_STRING,
};

exports.getHobbyLov = async (req, res) => {


  const sqlQuery = `
    SELECT  ACTUAL_CODE || ' - ' || DESCRIPTION  label, ACTUAL_CODE value FROM CODE_DESC WHERE CODE_TYPE='HOB'
  `;

  let connection;

  try {
    let arr0 = ""
    const response = [];

    connection = await oracledb.getConnection(config);

    const result = await connection.execute(
      sqlQuery,
    //   { relationNo }, // Bind the relationNo to the query
    //   { outFormat: oracledb.OUT_FORMAT_OBJECT } // Return results as JSON objects
    );

    // if (result.rows.length === 0) {
    //   res.status(404).json({ message: "No data found for the provided RELATION_NO." });
    // } else {
    // }
    // code for converting the array of arratys to the arry of objects 
    if (result.rows && result.rows.length > 0) {
      for (let i = 0; i < result.rows.length; i++) {
        for (let x = 0; x < result.metaData.length; x++) {
          arr0 +=
            '"' +
            [result.metaData[x].name.toLowerCase()] +
            '" : "' +
            result.rows[i][x] +
            '",';
        }

        response.push(JSON.parse("{" + arr0.replace(/,\s*$/, "") + "}"));
      }
console.log(response)
       return res.json(response);
    } else {
      res.status(204).send("No data found");
    }
} catch (error) {
    console.error("Error executing query:", error);
    res.status(500).send("Server error");
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing Oracle DB connection:", err);
      }
    }
  }
};
